# parser-mapping.ts — Spezifikation (kein Code)

**Stand:** Juli 2026  
**Zweck:** Tolerantes Parsen strukturierter HV-Inbound-Mails in das gemeinsame Lead-Datenmodell (identisch zu `persist-meldung-lead` / `vorgang-manuell`).

**Ziel-Implementierung:** `src/lib/inbound-mail/parser-mapping.ts` (CRM) — diese Datei ist nur die Spec.

---

## 1. Erkennungsformat

- **Zeilenbasiert:** `Label: Wert` (Doppelpunkt + optional Leerzeichen)
- **Labels case-insensitive**, Umlaute normalisiert (`ä→ae` optional bei Match)
- **Mehrzeilige Werte:** nur bei `Beschreibung:` — alle folgenden Zeilen bis nächstes bekanntes Label oder `---`
- **Sektionen:** `--- Pflicht ---`, `--- Optional ---` werden ignoriert
- **Betreff:** separat parsen (`NOTFALL` → Kategorie-Override nur wenn `Kategorie:` fehlt)

---

## 2. Feld-Mapping (Kern)

```typescript
// SPEC — Typen zur Orientierung

type InboundFieldKey =
  | 'objekt'
  | 'kategorie'
  | 'bereich'
  | 'beschreibung'
  | 'melder_name'
  | 'melder_einheit'
  | 'melder_email'
  | 'melder_telefon'
  | 'kostentraeger'
  | 'versicherungs_nr'
  | 'betrag_netto'
  | 'freigabe_hinweis'
  | 'zugang_hinweis'
  | 'erreichbarkeit_ab'

type ParsedInboundMeldung = {
  fields: Partial<Record<InboundFieldKey, string>>
  betreffNotfall: boolean
  anhaenge: string[] // URLs nach Upload-Pipeline
  rohtext: string
}
```

---

## 3. Label-Aliase je Feld

### `objekt` → `kunde_objekt_id` (Lookup)

| Aliase (Priorität absteigend) |
|-------------------------------|
| `Objekt` |
| `Liegenschaft` |
| `Adresse` |
| `Gebäude` |
| `Objektname` |
| `Melde-Link Objekt` |

**Lookup-Reihenfolge:**  
1. exakter Match `kunden_objekte.melde_slug` (case-insensitive)  
2. exakter Match `kunden_objekte.titel`  
3. Fuzzy enthält `titel` (Levenshtein ≤ 2 oder Token-Overlap)  
4. bei Mehrdeutigkeit → `null` + Fehler „Objekt nicht eindeutig“

---

### `kategorie` → `funnel_daten.melde_kategorie`

| Aliase |
|--------|
| `Kategorie` |
| `Art` |
| `Was ist passiert` |
| `Meldungsart` |
| `Fallart` |

**Wert-Aliase → DB:**

| Eingabe (normalisiert) | DB |
|------------------------|-----|
| `notfall`, `not-fall`, `akut`, `dringend` | `notfall` |
| `schaden`, `wasserschaden`, `sturmschaden` | `schaden` |
| `reparatur`, `defekt`, `kaputt` | `reparatur` |
| `sonstiges`, `anderes`, `sonst` | `sonstiges` |

**UI-Labels (exakt wie Formular):** `Notfall`, `Schaden`, `Reparatur`, `Sonstiges`

---

### `bereich` → `funnel_daten.melde_bereich`

| Aliase |
|--------|
| `Bereich` |
| `Gewerk` |
| `Was ist betroffen` |
| `Betroffen` |
| `Gewerk/Bereich` |

**Wert-Aliase → DB:**

| Eingabe / Label | DB |
|-----------------|-----|
| `Wasser / Rohr / WC`, `wasser`, `sanitär`, `bad`, `wc` | `wasser` |
| `Heizung / Warmwasser`, `heizung`, `warmwasser` | `heizung` |
| `Strom / Sicherung`, `strom`, `elektro`, `sicherung` | `strom` |
| `Fenster / Tür`, `fenster`, `tür`, `fenster_tuer` | `fenster_tuer` |
| `Dach / Regenrinne`, `dach`, `rinne` | `dach` |
| `Schimmel / Feuchtigkeit`, `schimmel`, `feuchtigkeit` | `schimmel` |
| `Baum / Sturm`, `baum`, `sturm` | `baum_notfall` |
| `Etwas anderes`, `sonstiges`, `andere` | `sonstiges` |

---

### `beschreibung` → `notizen`

| Aliase |
|--------|
| `Beschreibung` |
| `Was ist passiert` |
| `Schilderung` |
| `Problem` |
| `Details` |
| `Meldung` |

---

### `melder_name` → `melder_name`

| Aliase |
|--------|
| `Melder Name` |
| `Name` |
| `Mieter` |
| `Meldender` |
| `Kontakt Name` |

---

### `melder_einheit` → `melder_einheit`

| Aliase |
|--------|
| `Melder Einheit` |
| `Einheit` |
| `Wohnung` |
| `Whg` |
| `Wohnung / Einheit` |
| `Top` |
| `Lage` |

---

### `melder_email` → `melder_email`

| Aliase |
|--------|
| `Melder E-Mail` |
| `Melder Email` |
| `E-Mail` |
| `Email` |
| `Kontakt E-Mail` |

---

### `melder_telefon` → `melder_telefon`

| Aliase |
|--------|
| `Melder Telefon` |
| `Telefon` |
| `Tel` |
| `Handy` |
| `Mobil` |
| `Rückruf` |

**Normalisierung:** Leerzeichen/Schrägstriche entfernen für Speicherung optional; Anzeige original.

---

### `kostentraeger` → `kostentraeger`

| Aliase |
|--------|
| `Kostenträger` |
| `Kostentraeger` |
| `Kosten träger` |
| `Zahlungspflichtig` |
| `Kostenübernahme` |

**Wert-Aliase → DB:**

| Label (Formular) | DB |
|------------------|-----|
| `Gemeinschaft (WEG)`, `gemeinschaft`, `weg`, `gdv` | `gemeinschaft` |
| `Sondereigentum`, `sondereigentum`, `eigentümer` | `sondereigentum` |
| `Mieter`, `mieter`, `kleinreparatur` | `mieter` |
| `Versicherung`, `versicherung`, `versicherungsfall` | `versicherung` |
| `Noch unklar`, `unklar`, `unbekannt` | `unklar` |

---

### `versicherungs_nr` → `versicherungs_nr`

| Aliase |
|--------|
| `Versicherungsnummer` |
| `Versicherungs-Nr` |
| `Versicherungsnr` |
| `Schadennummer` |
| `Police` |
| `Versicherung Nr` |

**Pflicht wenn:** `kostentraeger === 'versicherung'` (Warnung, nicht harter Abbruch).

---

### `betrag_netto` → `preis_min` / `preis_max`

| Aliase |
|--------|
| `Geschätzter Betrag (netto)` |
| `Betrag` |
| `Kosten` |
| `Budget` |
| `Aufwand netto` |
| `Preis` |

**Parsing:** `1.234,56 EUR` → `1234.56`; ein Wert setzt min=max.

---

### `freigabe_hinweis` → (kein direktes DB-Feld)

| Aliase |
|--------|
| `Freigabe` |
| `Freigabe-Hinweis` |
| `Beauftragung` |
| `Direktauftrag` |

→ `org_freigabe_log.notiz` oder Lead-Notiz-Appendix; **ersetzt nicht** `org_freigabe_status`-Berechnung.

---

### `zugang_hinweis` → `funnel_daten.zugang_hinweis` (wenn Entscheidung #2)

| Aliase |
|--------|
| `Zugang / Schlüssel` |
| `Zugang` |
| `Schlüssel` |
| `Hausmeister` |
| `Zugangscode` |

---

### `erreichbarkeit_ab` → `funnel_daten.erreichbarkeit_ab` (wenn Entscheidung #1)

| Aliase |
|--------|
| `Erreichbar ab` |
| `Erreichbarkeit` |
| `Rückruf ab` |
| `Ab wann erreichbar` |

---

## 4. Persistenz-Mapping (nach Parse)

| Parsed | Lead-Felder |
|--------|-------------|
| alle Pflichtfelder + Kontakt | wie `persistMeldungLead` **ohne** `melde_tracking_token` |
| Kanal | `hv_manuell` |
| `erfassung_von` | `organisation` |
| `funnel_daten` | `{ melde_kategorie, melde_bereich, quelle: 'hv_mail', zugang_hinweis?, erreichbarkeit_ab? }` |
| `bereiche`, `situation`, `zeitraum` | wie `persist-meldung-lead` (aus Kategorie/Bereich ableiten) |
| `preis_*` | aus `betrag_netto` oder `mapMeldeToPrice` wenn leer |
| `kostentraeger_vorgeschlagen` | `false` (HV explizit) |
| Fotos | Anhänge-Pipeline → `funnel_daten.fotos[]` |

**Referenz-Implementierungen zum Angleichen:**

- `handwerks-plattform/src/lib/org/persist-meldung-lead.ts`
- `handwerks-plattform/src/app/api/org/vorgang-manuell/route.ts` (Freigabe aus Betrag)

---

## 5. Validierungsregeln (Parser-Output)

```typescript
// SPEC — Pseudocode

function validate(parsed: ParsedInboundMeldung): string[] {
  const errors: string[] = []
  if (!parsed.fields.objekt) errors.push('Objekt fehlt')
  if (!parsed.fields.kategorie) errors.push('Kategorie fehlt')
  if (!parsed.fields.bereich) errors.push('Bereich fehlt')
  if ((parsed.fields.beschreibung?.length ?? 0) < 8) errors.push('Beschreibung zu kurz')
  if (!parsed.fields.melder_name) errors.push('Melder Name fehlt')
  if (!parsed.fields.kostentraeger) errors.push('Kostenträger fehlt')
  const mail = parsed.fields.melder_email
  const tel = parsed.fields.melder_telefon ?? ''
  if (!isValidEmail(mail) && tel.replace(/\D/g, '').length < 6) {
    errors.push('Melder E-Mail oder Telefon erforderlich')
  }
  return errors
}
```

---

## 6. Unbekannte Zeilen

- Zeilen mit unbekanntem Label → `funnel_daten.parser_extras: Record<string, string>` (Audit, kein UI-Zwang)
- Kein Silent-Drop: im CRM als „Zusatz aus Mail“ anzeigen (optional, Welle 2)

---

## 7. Testfälle (für spätere Implementierung)

| Case | Erwartung |
|------|-----------|
| Minimale Pflicht-Mail + Telefon | Lead `hv_manuell`, alle Enums gesetzt |
| Betreff `NOTFALL`, ohne Kategorie-Zeile | `melde_kategorie=notfall` |
| `Liegenschaft:` statt `Objekt:` | gleicher Lookup |
| `Gewerk: Strom` | `melde_bereich=strom` |
| Doppeltes Objekt-Match | Fehler, kein Lead |
| `Kostenträger: Versicherung` ohne Nr. | Lead + CRM-Warnung |
| Anhang `foto.jpg` | URL in `funnel_daten.fotos` |

---

## 8. Abhängigkeiten

| Modul | Verwendung |
|-------|------------|
| `@/lib/validation` (`isValidEmail`, `isValidName`) | Kontakt + Name |
| `@/lib/org/melde-kategorien` | Kategorie-Labels |
| `@/lib/org/melde-bereiche` | Bereich-Labels |
| `@/lib/vorgang/kostentraeger` | `isKostentraeger` |
| `supabaseAdmin` + `kunden_objekte` | Objekt-Lookup scoped auf `auftraggeber_kunde_id` |
