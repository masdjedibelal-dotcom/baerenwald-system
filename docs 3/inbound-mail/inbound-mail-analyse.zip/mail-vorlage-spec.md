# Mail-Vorlage-Spec: HV-Inbound Schadenmeldung

**Stand:** Juli 2026  
**Ableitung aus:** [feld-inventar.md](./feld-inventar.md)  
**Prinzip:** So kurz wie möglich — nur Felder, die weder aus Stammdaten noch intern nachgetragen werden können.

---

## Betreff-Konvention

| Situation | Betreff |
|-----------|---------|
| Normal | `Meldung — {Objekt-Kurzname}` |
| Notfall | `NOTFALL — {Objekt-Kurzname}` |

→ Setzt `funnel_daten.melde_kategorie=notfall` und `zeitraum=sofort`. **Kein eigenes Dringlichkeits-Feld** in der Mail.

---

## Vorlage (Copy-Paste für Hausverwaltungen)

```
Betreff: Meldung — Musterhaus GH12

--- Pflicht ---

Objekt: GH12 Musterstraße
Kategorie: Reparatur
Bereich: Wasser / Rohr / WC
Beschreibung: Seit gestern tropft der Hahn im Bad Whg. 12, Wasser läuft in die Schublade.
Melder Name: Max Mustermann
Kostenträger: Gemeinschaft (WEG)

--- Optional ---

Melder Einheit: Whg. 12, 2. OG links
Melder E-Mail: max@beispiel.de
Melder Telefon: 0170 1234567
Versicherungsnummer: 
Geschätzter Betrag (netto): 
Freigabe: 
Zugang / Schlüssel: 
Erreichbar ab: 
```

---

## Feld-Spezifikation

### Pflicht-Sektion

| # | Feldname (exakt in Mail) | Beispielzeile | Parser-Zielformat | DB-Ziel |
|---|--------------------------|---------------|-------------------|---------|
| 1 | `Objekt:` | `Objekt: GH12 Musterstraße` | `string` (titel oder slug) | `kunde_objekt_id` via Lookup |
| 2 | `Kategorie:` | `Kategorie: Reparatur` | Enum → `notfall\|schaden\|reparatur\|sonstiges` | `funnel_daten.melde_kategorie` |
| 3 | `Bereich:` | `Bereich: Wasser / Rohr / WC` | Enum → `wasser\|heizung\|…` | `funnel_daten.melde_bereich` |
| 4 | `Beschreibung:` | `Beschreibung: …` | `string`, min. 8 Zeichen | `notizen` |
| 5 | `Melder Name:` | `Melder Name: Max Mustermann` | `string` | `melder_name` |
| 6 | `Kostenträger:` | `Kostenträger: Gemeinschaft (WEG)` | Enum → `gemeinschaft\|…` | `kostentraeger` |

**Kontakt-Regel (wie Meldeformular):** Mindestens eines von `Melder E-Mail:` oder `Melder Telefon:` muss befüllt sein. Parser validiert wie `isValidEmail` + Telefon ≥ 6 Zeichen.

### Optional-Sektion

| Feldname | Beispielzeile | Parser-Zielformat | DB-Ziel |
|----------|---------------|-------------------|---------|
| `Melder Einheit:` | `Melder Einheit: Whg. 12` | `string` | `melder_einheit` |
| `Melder E-Mail:` | `Melder E-Mail: a@b.de` | E-Mail lowercase | `melder_email` |
| `Melder Telefon:` | `Melder Telefon: 0170 …` | normalisierte Ziffern | `melder_telefon` |
| `Versicherungsnummer:` | nur wenn Kostenträger Versicherung | `string` | `versicherungs_nr` |
| `Geschätzter Betrag (netto):` | `Geschätzter Betrag (netto): 800` | `number` EUR | `preis_min`/`preis_max` |
| `Freigabe:` | `Freigabe: bis 500 EUR direkt beauftragen` | Freitext → Log | `org_freigabe_log.notiz` / manuell |
| `Zugang / Schlüssel:` | Freitext | `string` | `funnel_daten.zugang_hinweis`* |
| `Erreichbar ab:` | `Erreichbar ab: 14:00` | `string` | `funnel_daten.erreichbarkeit_ab`* |

\* Nur wenn Entscheidung #1/#2 in [feld-inventar.md](./feld-inventar.md) umgesetzt; sonst an `Beschreibung` anhängen.

---

## Enum-Werte (identisch zum Meldeformular)

### Kategorie (`Kategorie:`)

| UI-Label (Mail) | DB-Wert |
|-----------------|---------|
| Notfall | `notfall` |
| Schaden | `schaden` |
| Reparatur | `reparatur` |
| Sonstiges | `sonstiges` |

### Bereich (`Bereich:`)

| UI-Label (Mail) | DB-Wert |
|-----------------|---------|
| Wasser / Rohr / WC | `wasser` |
| Heizung / Warmwasser | `heizung` |
| Strom / Sicherung | `strom` |
| Fenster / Tür | `fenster_tuer` |
| Dach / Regenrinne | `dach` |
| Schimmel / Feuchtigkeit | `schimmel` |
| Baum / Sturm | `baum_notfall` |
| Etwas anderes | `sonstiges` |

### Kostenträger (`Kostenträger:`)

| UI-Label (Mail) | DB-Wert |
|-----------------|---------|
| Gemeinschaft (WEG) | `gemeinschaft` |
| Sondereigentum | `sondereigentum` |
| Mieter | `mieter` |
| Versicherung | `versicherung` |
| Noch unklar | `unklar` |

---

## System-Felder nach erfolgreichem Parse

| Feld | Wert |
|------|------|
| `kanal` | `hv_manuell` (oder `hv_mail` nach Entscheidung) |
| `erfassung_von` | `organisation` |
| `anlass` | `meldung` |
| `auftraggeber_kunde_id` | aus Absender / CRM-Zuordnung |
| `hv_meldung_status` | `neu` |
| `org_freigabe_status` | aus `Geschätzter Betrag` + Org-Schwelle, sonst `nicht_noetig` |
| `melde_tracking_token` | `null` |
| `vorgang_phase` | `eingegangen` |
| Adresse | von `kunden_objekte` übernehmen |

---

## Bewusst NICHT in der Vorlage (mit Begründung)

| Feld | Begründung |
|------|------------|
| **Dringlichkeit / Zeitraum** | Über Betreff `NOTFALL` oder Kategorie `Notfall` abgedeckt — gleiche Logik wie Formular-Ableitung |
| **Kostenstelle** | Liegt im Objektstamm (`kunden_objekte.kostenstelle_nr`); HV pflegt einmalig im Portal/CRM |
| **Auftraggeber / Org-Name** | Aus Absender-E-Mail + `kunden.org_kennung` auflösbar |
| **Fachdetail-Fragen** | Dynamisch (0–2 je Bereich); in Mail nicht wartbar — Inhalt gehört in `Beschreibung`, Preis ggf. `preis_unsicher` |
| **Fotos als Feldzeilen** | E-Mail-Anhänge separat verarbeiten; kein `Fotos:`-Label nötig |
| **Org-Freigabe-Status** | Portal-Regelwerk (`freigabe_modus`, `freigabe_schwelle_eur`); optionaler Freitext `Freigabe:` nur als Hinweis |
| **Einheit aus Stamm-Dropdown** | Erst ab Welle 2/3; bis dahin Freitext `Melder Einheit:` |

---

## Validierung (Parser → Antwort an HV)

| Fehler | HTTP / Antwort |
|--------|----------------|
| Objekt nicht eindeutig | Rückmail: „Objekt bitte präzisieren (Slug oder exakter Titel)“ |
| Beschreibung &lt; 8 Zeichen | Ablehnung |
| Weder E-Mail noch Telefon | Ablehnung |
| Unbekannte Enum-Werte | Best-effort + Hinweis im CRM (`unklar` / `sonstiges`) |
| Kostenträger Versicherung ohne Nr. | Lead anlegen, CRM-Task „Versicherungsnr. nachfordern“ |

---

## Abweichung Formular ↔ Mail (bewusst)

| Aspekt | Formular | Mail |
|--------|----------|------|
| Objekt | URL-Slug | Textfeld `Objekt:` |
| Kostenträger | nicht abgefragt | **Pflicht** (HV weiß es eher als Mieter) |
| Kontakt Pflicht | E-Mail oder Telefon | gleiche Regel |
| Fachdetail | dynamisch | in Beschreibung |

**Konsistenz-Regel:** Alle Enum-**Labels** und DB-**Werte** sind identisch (s. Tabellen oben). Keine dritte Benennung einführen.
