# Feld-Inventar: Inbound-Mail ↔ CRM ↔ Meldeformular

**Stand:** Juli 2026  
**Quellen:** `baerenwald-crm-dashboard` (Schema, `LeadOrgKontextBlock`, `org-freigabe-logic`, Export-API Spiegel), `handwerks-plattform` (`MeldeFormular`, `/api/meldung`, `persist-meldung-lead`, `vorgang-manuell`)  
**Zielkanal Mail:** strukturierte HV-Inbound-Mail → Lead mit `kanal=hv_manuell` (oder künftig `hv_mail`), `erfassung_von=organisation`, `anlass=meldung`

---

## Schritt 1 — CRM-Ist: Felder im Lebenszyklus Meldung → Export

### 1.1 Lead (`leads`) — Erfassung & Vorgang

| DB-Spalte | Typ | Technisch | Fachlich blockiert | Enum / Default | Setzer heute |
|-----------|-----|-----------|-------------------|----------------|--------------|
| `auftraggeber_kunde_id` | uuid FK | optional | Org-Kontext, Portal-Freigabe, Export-Filter | — | System (aus `org_kennung` / Session / CRM-Zuordnung) |
| `kunde_objekt_id` | uuid FK | optional | **Export-Kostenstelle** (über `kunden_objekte.kostenstelle_nr`), Objekt-Kontext im CRM | — | Melder-URL / HV-Portal / CRM |
| `kanal` | `lead_kanal` | NOT NULL (implizit) | Reporting, Workflow-Unterscheidung | `hv_melder_link`, `hv_direkt`, `hv_einladung`, `hv_manuell`, `hv_katalog` | System |
| `anlass` | text | optional | Org-UI-Blöcke | `meldung`, `projekt`, `servicepaket`, `katalog`, `fixauftrag`, `sonstiges` | System (`meldung` bei HV-Meldungen) |
| `erfassung_von` | text | optional | Org-Freigabe-Logik (nur `melder` → Mieter-Schadenpfad) | `melder`, `organisation`, `crm` | System |
| `melder_name` | text | optional | Kontakt, Datenschutz-Export | — | Melder / HV / Mail |
| `melder_einheit` | text | optional | Duplikat-Hinweis (24h), Ortsangabe | — | Melder / HV / Mail |
| `melder_email` | text | optional | Rückfragen, Bestätigungsmail | — | Melder / HV / Mail |
| `melder_telefon` | text | optional | Rückfragen (Ersatz wenn keine E-Mail) | — | Melder / HV / Mail |
| `notizen` | text | optional | Beschreibung im CRM, Preiskalkulation-Kontext | — | Melder / HV / Mail |
| `kontakt_nachricht` | text | optional | Zusatztext (HV-manuell) | — | HV-Portal |
| `funnel_daten` | jsonb | optional | Kategorie, Bereich, Fachdetails, Fotos | Keys s. unten | System / Melder |
| `funnel_daten.melde_kategorie` | string | — | Preis, Notfall, Kostenträger-Vorschlag | `notfall`, `schaden`, `reparatur`, `sonstiges` | Melder / HV |
| `funnel_daten.melde_bereich` | string | — | Gewerk-Mapping, Fachdetail-Fragen | `wasser`, `heizung`, `strom`, `fenster_tuer`, `dach`, `schimmel`, `baum_notfall`, `sonstiges` | Melder / HV |
| `funnel_daten.fachdetailAnswers` | object | — | Preisspanne (`mapMeldeToPrice`) | dynamisch je Bereich | Melder (Formular) |
| `funnel_daten.fotos` | string[] | — | CRM-Anzeige, Datenschutz | URLs | Melder (Upload) |
| `funnel_daten.quelle` | string | — | Audit | Kanal-Wert | System |
| `situation` | text | optional | Legacy-Funnel | `kaputt`, `notfall` (über Kategorie) | System |
| `bereiche` | text[] | optional | Legacy-Preisrechner | z. B. `sanitaer`, `heizung` | System (aus `melde_bereich`) |
| `zeitraum` | text | optional | Dringlichkeit-Anzeige in Mails | `sofort`, `diese_woche`, `flexibel` | System (aus Kategorie) |
| `plz`, `strasse`, `hausnummer` | text | optional | Adress-Kontext | vom Objekt übernommen | System |
| `kostentraeger` | text | optional | **Rechnung/Export-Spalte**, Versicherungsakte | `gemeinschaft`, `sondereigentum`, `mieter`, `versicherung`, `unklar` | HV-Portal manuell / CRM / Vorschlag |
| `kostentraeger_vorgeschlagen` | boolean | default `false` | UI-Hinweis „Vorschlag“ | — | System |
| `versicherungs_nr` | text | optional | Versicherungsfall-Dokumentation | — | CRM (manuell) |
| `org_freigabe_status` | text | NOT NULL default `nicht_noetig` | **Partner-Anfrage blockiert** bei `ausstehend`/`abgelehnt` (außer Notmaßnahme) | `nicht_noetig`, `ausstehend`, `freigegeben`, `abgelehnt` | System / Portal / CRM |
| `hv_meldung_status` | text | optional | HV-Workflow im Portal | `neu`, `notmassnahme`, `angebot_eingefordert`, `kleinreparatur`, `abgelehnt`, `abgeschlossen` | Portal / CRM |
| `preis_min`, `preis_max` | numeric | optional | Freigabe-Schwelle (`freigabe_schwelle_eur`) | — | System (`mapMeldeToPrice`) |
| `preis_unsicher` | boolean | optional | HV sieht „Preis nach Prüfung“ | — | System |
| `melde_tracking_token` | text | optional unique | Mieter-Statuslink | — | System (nur Mieter-Kanal) |
| `vorgang_phase` | text | optional | interne Phase | default `eingegangen` | System |
| `duplikat_hinweis` | boolean | default `false` | CRM-Warnung | — | System |
| `einladung_token`, `einladung_status` | uuid / text | optional | Einladungs-Flow | `offen`, `ergaenzt`, `entfallen` | CRM / Portal |

**`funnel_daten` Keys (ab Welle 2/3, noch nicht im Meldeformular):** `katalog_produkt_slug`, `objekt_einheit_id` — für Katalog-/Einheiten-Bezug reserviert.

### 1.2 Objekt-Stamm (`kunden_objekte`) — abgeleitet, nicht pro Meldung

| DB-Spalte | Fachlich | Setzer |
|-----------|----------|--------|
| `melde_slug` | URL-Auflösung `/melden/{org}/{slug}` | CRM / Portal |
| `kostenstelle_nr` | **Rechnungs-CSV Kostenstelle**; Fallback Auftrags-ID-Prefix | CRM / Portal |
| `einheiten_hinweis` | Hilfetext im Formular | CRM |
| `objekt_einheiten` (Welle 2/3) | strukturierte Einheit | CRM |

### 1.3 Organisation (`kunden`)

| DB-Spalte | Fachlich | Setzer |
|-----------|----------|--------|
| `org_kennung` | Melde-Link, Inbound-Absender-Zuordnung | CRM |
| `freigabe_modus` | `direkt` vs `freigabe` | CRM |
| `freigabe_schwelle_eur` | ab Betrag Freigabe nötig | CRM |
| `notfall_direkt` | Notfall umgeht Freigabe | CRM |

### 1.4 Auftrag (`auftraege`)

| DB-Spalte | Fachlich blockiert | Setzer |
|-----------|-------------------|--------|
| `kunde_objekt_id` | Objekt in Rechnung/Export | CRM (aus Lead) |
| `kostentraeger` | Export-Spalte Kostenträger | CRM (**nicht auto vom Lead**) |
| `versicherungs_nr`, `versicherungsakte_pdf_url` | Versicherungsfall | CRM |

### 1.5 Rechnung (`rechnungen`) + Export

| DB-Spalte / Quelle | Fachlich | Setzer |
|--------------------|----------|--------|
| `kostentraeger` | CSV-Spalte „Kostenträger“ | CRM |
| `lohnanteil_eur`, `lohnanteil_prozent` | CSV Lohnanteil | CRM / Katalog |
| `auftrag_id` → Objekt → `kostenstelle_nr` | CSV „Kostenstelle“; leer → Auftrags-ID-Kürzel | Stammdaten |

### 1.6 Fachliche Blocker (Kurz)

1. **Partner-Anfrage:** `org_freigabe_status ∈ {ausstehend, abgelehnt}` → blockiert (`orgFreigabeBlockiertPartner`), außer `hv_meldung_status=notmassnahme`.
2. **Export Kostenstelle:** `kunde_objekt_id` muss gesetzt sein + `kostenstelle_nr` im Objektstamm (sonst Fallback).
3. **Kostenträger in Rechnung:** manuell auf Auftrag/Rechnung; Lead-Wert wird nicht automatisch vererbt.
4. **Versicherung:** `kostentraeger=versicherung` sinnvoll nur mit `versicherungs_nr` (CRM-Pflege).

---

## Schritt 2 — Formular-Ist: Öffentliche Meldestrecke `/melden/…`

**Route:** `/melden/{org_kennung}` oder `/melden/{org_kennung}/{melde_slug}`  
**API:** `POST /api/meldung`, Fotos `POST /api/meldung/upload`  
**Persistenz:** `kanal=hv_melder_link`, `erfassung_von=melder`

### Wizard-Schritte & Felder

| Schritt | Feld (UI) | Pflicht | DB-Ziel | Anmerkung |
|---------|-----------|---------|---------|-----------|
| (URL) | Objekt | implizit | `kunde_objekt_id` | via `melde_slug`, nicht editierbar |
| 1 Kategorie | Was ist passiert? | ja (Auswahl) | `funnel_daten.melde_kategorie` | `notfall`, `schaden`, `reparatur`, `sonstiges` |
| 2 Bereich | Was ist betroffen? | ja | `funnel_daten.melde_bereich` | 8 Optionen, s. Enum oben |
| 3 Fachdetail | 0–2 Fragen | ja wenn angezeigt | `funnel_daten.fachdetailAnswers` | abhängig von Kategorie+Bereich+PLZ |
| 4 Details | Beschreibung | ja (min. 8) | `notizen` | — |
| 4 Details | Fotos | nein | `funnel_daten.fotos` | max. Portal-Upload |
| 5 Kontakt | Name | ja | `melder_name`, `name` | — |
| 5 Kontakt | Wohnung/Einheit | nein (kein `*`) | `melder_einheit` | Freitext |
| 5 Kontakt | E-Mail | bedingt | `melder_email` | Pflicht wenn Telefon &lt; 6 Zeichen |
| 5 Kontakt | Telefon | bedingt | `melder_telefon` | Pflicht wenn keine gültige E-Mail |

**Nicht im Formular, aber API-fähig:** `dringlichkeit` (wird bei `notfall` → `zeitraum=sofort` abgeleitet).

**HV-Portal-Parallelen (nicht öffentliches Formular):**

| Flow | Kanal | Zusätzliche Pflichtfelder |
|------|-------|---------------------------|
| HV-Direkt (`/api/org/meldung-direkt`) | `hv_direkt` | wie Meldeformular minus Fotos-Pflicht |
| HV manuell (`/api/org/vorgang-manuell`) | `hv_manuell` | Titel, Beschreibung, Objekt, **Kostenträger**, optional `preisNetto` |
| Einladung ergänzen | `hv_einladung` | wie Meldeformular |

---

## Schritt 3 — Abgleich-Matrix

**Legende Kategorie:** `MATCH` · `GAP-CRM` · `GAP-FORMULAR` · `MAIL-ONLY`  
**Mail?** = soll Inbound-Vorlage abfragen · **Pflicht Mail?** = in Pflicht-Sektion der Vorlage

| Feld (fachlich) | DB-Spalte / JSON | CRM braucht | Formular fragt | Mail sollte abfragen | Pflicht Mail? | Parser-Format | Fallback wenn fehlt | Kat. |
|-----------------|------------------|-------------|----------------|----------------------|---------------|---------------|----------------------|------|
| Auftraggeber (Organisation) | `auftraggeber_kunde_id` | ja | nein (URL) | nein | nein | — | Absender-Domain / feste HV-Zuordnung | MATCH |
| Objekt / Liegenschaft | `kunde_objekt_id` | **ja** (Export) | nein (URL-Slug) | **ja** | **ja** | `Objekt: {titel oder slug}` | CRM manuell zuordnen; Blocker Export | GAP-FORMULAR |
| Kategorie (Art des Falls) | `funnel_daten.melde_kategorie` | ja | ja | **ja** | **ja** | Enum DE oder ID | `reparatur` | MATCH |
| Bereich / Gewerk | `funnel_daten.melde_bereich` | ja | ja | **ja** | **ja** | Enum s. Meldeformular | `sonstiges` | MATCH |
| Fachdetail-Antworten | `funnel_daten.fachdetailAnswers` | ja (Preis) | ja (dynamisch) | nein | nein | — | in Beschreibung; `preis_unsicher=true` | GAP-FORMULAR |
| Beschreibung | `notizen` | ja | ja | **ja** | **ja** | Freitext ≥8 Zeichen | Ablehnung / Rückfrage | MATCH |
| Fotos | `funnel_daten.fotos` | hilfreich | optional | nein | nein | Anhänge | leer | MATCH |
| Melder Name | `melder_name` | ja | ja | **ja** | **ja** | Freitext | „Unbekannt“ + Rückfrage | MATCH |
| Melder Einheit | `melder_einheit` | empfohlen | optional | **ja** | nein | Freitext | leer | MATCH |
| Melder E-Mail | `melder_email` | empfohlen | bedingt | **ja** | bedingt* | E-Mail | Telefon Pflicht | MATCH |
| Melder Telefon | `melder_telefon` | empfohlen | bedingt | **ja** | bedingt* | Telefon | E-Mail Pflicht | MATCH |
| Dringlichkeit / Zeitraum | `zeitraum` | Anzeige | abgeleitet | nein | nein | Betreff `NOTFALL` | aus Kategorie `notfall` | MAIL-ONLY |
| Kostenträger | `kostentraeger` | **ja** (Rechnung) | nein | **ja** | **ja** | Enum DE-Labels | `unklar` | GAP-FORMULAR |
| Versicherungsnummer | `versicherungs_nr` | bei Versicherung | nein | **ja** | bedingt** | Freitext | leer; CRM nachpflegen | GAP-FORMULAR |
| Kostenstelle | `kunden_objekte.kostenstelle_nr` | Export | nein | nein | nein | — | Objektstamm / Auftrags-ID | MATCH |
| Geschätzter Betrag (netto) | `preis_min`/`preis_max` | Freigabe-Schwelle | nein (Portal) | optional | nein | `Betrag: 1234,56 EUR` | `preis_unsicher`; Freigabe nach Angebot | MAIL-ONLY |
| Freigabe-Anweisung | `org_freigabe_status` (indirekt) | ja | nein (Portal-Regel) | optional | nein | `Freigabe: bis 500 EUR direkt` | Org-Defaults (`freigabe_modus`, Schwelle) | MAIL-ONLY |
| Kanal | `kanal` | ja | System | nein | nein | — | `hv_manuell` | MATCH |
| Erfassung | `erfassung_von` | ja | System | nein | nein | — | `organisation` | MATCH |
| Anlass | `anlass` | ja | System | nein | nein | — | `meldung` | MATCH |
| HV-Workflow-Status | `hv_meldung_status` | Portal | System | nein | nein | — | `neu` | MATCH |
| Org-Freigabe-Status | `org_freigabe_status` | Partner-Gate | System/Portal | nein | nein | — | aus Betrag + Org-Settings | MATCH |
| Mieter-Statuslink | `melde_tracking_token` | Mieter-Kanal | System | nein | nein | — | null (HV-Mail) | MATCH |
| Titel (Kurzfassung) | `funnel_daten.titel` / Notizen | UX | nein | optional | nein | erste Zeile Notizen | aus Beschreibung kürzen | GAP-FORMULAR |
| Erreichbarkeit ab Uhrzeit | — | nein | nein | optional | nein | Freitext | in Beschreibung | GAP-CRM |
| Zugang / Schlüssel | — | nein | nein | optional | nein | Freitext | in Beschreibung | GAP-CRM |
| Einheit (Dropdown) | `objekt_einheiten.id` | ab Welle 2/3 | nein (Freitext) | nein*** | nein | — | `melder_einheit` Freitext | ab Welle 2/3 |
| Katalog-Produkt | `funnel_daten.katalog_*` | ab Welle 3 | nein | nein | nein | — | — | ab Welle 3 |

\* Mail-Pflicht Kontakt: mindestens E-Mail **oder** Telefon (wie Formular-API).  
\** Pflicht in Mail nur wenn `Kostenträger: Versicherung`.  
\*** Ab Welle 2/3 optional `Einheit: {Bezeichnung aus Stamm}` statt Freitext.

---

## Schritt 4 — Offene Entscheidungen

| # | Thema | Vorschlag | Aufwand | Entscheidung offen |
|---|-------|-----------|---------|-------------------|
| 1 | **GAP-CRM: `erreichbarkeit_ab`** (Uhrzeit/Fenster) | Neue Spalte `leads.melder_erreichbarkeit text` oder JSON in `funnel_daten` | S | ja/nein |
| 2 | **GAP-CRM: `zugang_hinweis`** (Schlüssel, Hausmeister) | `funnel_daten.zugang_hinweis` (kein Schema-Migration) | S | ja/nein |
| 3 | **GAP-FORMULAR: Kostenträger** im Meldeformular | Schritt 5 oder HV-only; Mieter oft unbekannt → Default `unklar` | M | ja/nein |
| 4 | **GAP-FORMULAR: Versicherungs-Nr.** | Bedingtes Feld wenn Kategorie `schaden` + optional Kostenträger | S | ja/nein |
| 5 | **Fachdetail in Mail** | Nicht abfragen; Beschreibung + `preis_unsicher` vs. statische 1-Zeiler je Bereich in Vorlage | S / M | ja/nein |
| 6 | **Kanal `hv_mail`** vs. Reuse `hv_manuell` | Eigenes Enum für Reporting (`hv_mail`) | S | ja/nein |
| 7 | **Objekt-Auflösung Inbound** | Pflicht `Objekt:` mit Fuzzy-Match auf `titel` + `melde_slug` | M | ja/nein |
| 8 | **Einheiten-Dropdown** (Welle 2/3) | `objekt_einheiten` + Mail/Formular `Einheit:` gegen Stamm matchen | L | später |
| 9 | **Lead→Auftrag Kostenträger-Vererbung** | Beim Angebots-/Auftrags-Wizard automatisch kopieren | M | ja/nein |
| 10 | **Foto-Inbound** | Anhänge → Storage → `funnel_daten.fotos` | M | ja/nein |

---

## Referenzen (Code)

- CRM Org-Kontext: `src/components/anfragen/LeadOrgKontextBlock.tsx`
- CRM Labels/Enums: `src/lib/org/org-portal-helpers.ts`
- Freigabe-Logik: `src/lib/org/org-freigabe-logic.ts`
- Schema HV: `supabase/migrations/20260708120000_organisation_portal_stamm.sql`, `20260801120000_hv_plattform_wellen_0_3.sql`
- Meldeformular: `handwerks-plattform/src/components/melden/MeldeFormular.tsx`
- Persistenz: `handwerks-plattform/src/lib/org/persist-meldung-lead.ts`
- HV manuell: `handwerks-plattform/src/app/api/org/vorgang-manuell/route.ts`
- Export: `handwerks-plattform/src/app/api/org/export/rechnungen/route.ts`
